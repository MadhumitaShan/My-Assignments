package week6.day2;

public class Learnkeyword {
	
	public Learnkeyword() {
		System.out.println("This is a constructor from super class");
	}

	public static void readData() {
		System.out.println("This is readData from super class");
	
	}

	
}
