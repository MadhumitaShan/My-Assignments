package stepDefinition;

import org.openqa.selenium.chrome.ChromeDriver;

public class ProjectSpecificMethod {

	public static ChromeDriver driver;
	
	
}
