package week1.day2;

public class EdgeBrowser {

	public static void main(String[] args) {
		System.out.println("=====EdgeBrowser.java=========");
		Browser edge = new Browser();
		edge.launchBrowser("Edge");
		edge.loadUrl();
		
	}

}
