package week1.day1;

public class LearnDataTypes {

	public static void main(String[] args) {
		// Syntax to store value
		//DataType variable = value for the variable.
		// Variable ---> can able to store values based on my data type.
		int age = 30;
//		byte amount = 128;
		float pieValue = 3.145F; // float --> value ends with either f(lowercase) or F(Uppercase)
		long cardNumber = 9654123487543921L; // long -> value ends with l(lowercase) or L(Uppercase)
		boolean areYouMarried = true;
		String name = "gokul";
		char intial = 's';
		char number = 64;
		char ascii65 = 65;
		System.out.println("Age : "+age);
		System.out.println(cardNumber);
		System.out.println(pieValue);
		System.out.println(name);
		System.out.println(number);
		System.out.println(ascii65);
	}

}
