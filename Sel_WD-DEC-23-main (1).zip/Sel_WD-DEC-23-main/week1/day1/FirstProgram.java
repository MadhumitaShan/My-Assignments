package week1.day1;

public class FirstProgram {
	// type main ---> press  a key ctrl+space release and then enter 
	
	// Main method ---> entire point of my program
	// Without main method , can't able to execute 
	public static void main(String[] args) {
		// Print any text 
		// type syso ---> press  a key ctrl+space release and then enter 
		// To complete the statement --> ;(semicolon)
		System.out.println("Hello!, Welcome you all to TestLeaf :)");
	}
}
