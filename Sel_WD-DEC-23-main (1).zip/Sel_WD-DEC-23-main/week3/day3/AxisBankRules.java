package week3.day3;

public interface AxisBankRules extends RBI {
	
	
	public void internetBanking();
	
	public void mobileBanking();
	
	

	
	

}
