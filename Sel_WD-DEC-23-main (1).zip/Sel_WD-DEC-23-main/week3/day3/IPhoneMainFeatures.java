package week3.day3;

public interface IPhoneMainFeatures {
	
	public void camera();
	
	public void mic();
	
	public void itunes();
	
	public void chargingPort();
	
	public void networkConnectivity();
	
	public void battery();
	

}
