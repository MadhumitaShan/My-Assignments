package week3.day3;

public interface IPhoneUI {
	
	
	public void appLibrary();
	
	public void siri();
	
	public void screenResolution();

}
