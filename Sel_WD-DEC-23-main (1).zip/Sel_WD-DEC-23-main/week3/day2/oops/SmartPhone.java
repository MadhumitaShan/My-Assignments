package week3.day2.oops;

public class SmartPhone {

	public void playMusic() {
		System.out.println("Play music from youtube");
	}
	
	public void openApp() {
		System.out.println("Open the app");
	}
	
	public void playGames() {
		System.out.println("Play a game");
	}
	
	public void sendMsg() {
		System.out.println("Send a message to my friend");
	}
	
	public void getApp() {
		System.out.println("download apps from play store");
	}
	
	public void makeCall() {
		System.out.println("Make a call");
	}
}
